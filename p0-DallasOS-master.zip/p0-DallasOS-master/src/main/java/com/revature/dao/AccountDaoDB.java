package com.revature.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.revature.beans.Account;
import com.revature.beans.Account.AccountType;
import com.revature.beans.User;
import com.revature.beans.User.UserType;
import com.revature.utils.*;
import java.util.*;
/**
 * Implementation of AccountDAO which reads/writes to a database
 */
public class AccountDaoDB implements AccountDao {
	public static Connection conn;
	public static Statement stmt;
	public static PreparedStatement pstmt;
	public static ResultSet rs;
	
	public static void getConnection() {
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bankofaridholusers", "root", "root");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void closeResource() {
		try {
			if (rs != null)
				rs.close();
			if (pstmt != null)
				pstmt.close();
			if (stmt != null)
				stmt.close();
			if (conn != null)
				conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public Account addAccount(Account acc) {
		getConnection();
		String query = "Insert into accounts (owner_id, balance, approved, account_type) values (?,?,?,?)";
		
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, acc.getOwnerId());
			pstmt.setDouble(2, acc.getBalance());
			pstmt.setBoolean(3, acc.isApproved());
			pstmt.setString(4, acc.getType().name());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return acc;
	}

	public Account getAccount(Integer actId) {
		getConnection();
		String query = "select * from accounts where account_id = " + actId;
		Account a = null;
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);
			if (rs.next()) {
				a = new Account();
				a.setId(rs.getInt("account_id"));
				a.setOwnerId(rs.getInt("owner_id"));
				a.setBalance(rs.getDouble("balance"));
				a.setApproved(rs.getBoolean("approved"));
				if (rs.getString("account_type") != null) {
                    if(rs.getString("account_type").equals(AccountType.CHECKING.name())) {
                        a.setType(AccountType.CHECKING);
                    } else {
                        a.setType(AccountType.SAVINGS);                    }
                }
			}				
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return a;
	}

	public List<Account> getAccounts() {
		getConnection();
		List<Account> accountList = new ArrayList<Account>();
		String query = "select * from accounts";
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);
		
			while (rs.next()) {
				Account acc = new Account();
				acc.setId(rs.getInt("id"));
				acc.setOwnerId(rs.getInt("owner_id"));
				acc.setBalance(rs.getDouble("balance"));
				acc.setApproved(rs.getBoolean("approved"));
				if (rs.getString("type") != null) {
                    if(rs.getString("type").equals(AccountType.CHECKING.name())) {
                        acc.setType(AccountType.CHECKING);
                    } else {
                        acc.setType(AccountType.SAVINGS);                    }
                }
				accountList.add(acc);}
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return accountList;
	}

	public List<Account> getAccountsByUser(User user) {
		getConnection();
		String query = "select * from accounts where owner_id = " + user.getId();
		List<Account> accountList = new ArrayList<Account>();
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);
			while (rs.next()) {
				Account acc = new Account();
				acc.setId(rs.getInt("account_id"));
				acc.setOwnerId(rs.getInt("owner_id"));
				acc.setBalance(rs.getDouble("balance"));
				acc.setApproved(rs.getBoolean("approved"));
				if (rs.getString("account_type") != null) {
                    if(rs.getString("account_type").equals(AccountType.CHECKING.name())) {
                        acc.setType(AccountType.CHECKING);
                    } else {
                        acc.setType(AccountType.SAVINGS);                    }
                }
				accountList.add(acc);}
			} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return accountList;
	}
	
	public Account updateAccount(Account a) {
		getConnection();
		String query = "Update accounts set owner_id=?, balance=?, approved=?, account_type=? where account_id=" + a.getId();

		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, a.getOwnerId());
			pstmt.setDouble(2, a.getBalance());
			pstmt.setBoolean(3, a.isApproved());
			pstmt.setString(4, a.getType().name());
			int result = pstmt.executeUpdate();
			if (result == 0);
				return null;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return a;
	}

	public boolean removeAccount(Account acc) {
		getConnection();
		String query = "delete from accounts where account_id = " + acc.getId();
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);
			System.out.println("Vault Has Been Successfully Emptied");
		} catch (SQLException e) {
			System.out.println("Your Vault Cannot Be Emptied");
		}
		return false;
	}
}