package com.revature.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.revature.beans.User;
import com.revature.beans.User.UserType;

/**
 * Implementation of UserDAO that reads/writes to a relational database
 */
public class UserDaoDB implements UserDao {

	public static Connection conn;
	public static Statement stmt;
	public static PreparedStatement pstmt;
	public static ResultSet rs;

	public static void getConnection() {
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bankofaridholusers", "root", "root");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void closeResource() {
		try {
			if (rs != null)
				rs.close();
			if (pstmt != null)
				pstmt.close();
			if (stmt != null)
				stmt.close();
			if (conn != null)
				conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public User addUser(User u) {
		getConnection();
		String query = "Insert into Users () values (?,?,?,?,?,?)";
		
		try {
//			stmt = conn.createStatement();
//			rs = stmt.executeQuery(query);
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, u.getId());
			pstmt.setString(2, u.getFirstName());
			pstmt.setString(3, u.getLastName());
			pstmt.setString(4, u.getUsername());
			pstmt.setString(5, u.getPassword());
			System.out.println("user_type = " + u.getUserType());
			pstmt.setObject(6, u.getUserType().toString());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return u;
	}

	public User getUser(Integer userId) {
		getConnection();
		String query = "get * from Users where id = " + userId;
		User u = null;
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);
			if (rs.next()) {
				u.setId(rs.getInt("id"));
				u.setFirstName(rs.getString("first_name"));
				u.setLastName(rs.getString("last_name"));
				u.setPassword(rs.getString("Password"));
				u.setUsername(rs.getString("Username"));
				u.setUserType((UserType)rs.getObject("user_type"));
				//Find a way to reference usertype here, modify later
//				u.getAccounts(rs.);
				//Find a way to reference accounts here
			}
							
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return u;
	}

	public User getUser(String username, String pass) {
		getConnection();
		List<User> userList = new ArrayList<User>();
		String query = "SELECT * FROM Users WHERE username='" + username + "' AND pwd='" + pass + "'";
		
		User user = null;
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);
	
            if (rs.next()) {
            	user = new User();
                user.setId(rs.getInt("id"));
                user.setFirstName(rs.getString("first_name"));
                user.setLastName(rs.getString("last_name"));
                user.setUsername(rs.getString("username"));
                String type = rs.getString("user_type");
                UserType enumVal = UserType.valueOf(type);
                user.setUserType(enumVal);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return user;
    }

	public List<User> getAllUsers() {
		getConnection();
		List<User> userList = new ArrayList<User>();
		String query = "select * from users";
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);
		
			while (rs.next()) {
				User u = new User();
				u.setId(rs.getInt("id"));
				u.setFirstName(rs.getString("first_name"));
				u.setLastName(rs.getString("last_name"));
				u.setPassword(rs.getString("pwd"));
				u.setUsername(rs.getString("username"));
				if (rs.getString("user_type").equals(UserType.CUSTOMER.toString())) {
					u.setUserType(UserType.CUSTOMER);
				} else {
					u.setUserType(UserType.EMPLOYEE);
				}
				//u.getAccounts(List<User>);
				//Find a way to reference accounts here
				userList.add(u);}
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return userList;
	}

	public User updateUser(User u) {
		getConnection();
		String query = "update User set first_name = ?, last_name = ?, username = ?, password = ?, userType = ? where id = ?";
//		
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(6, u.getId());
			pstmt.setString(1, u.getFirstName());
			pstmt.setString(2, u.getLastName());
			pstmt.setString(3, u.getUsername());
			pstmt.setString(4, u.getPassword());
			pstmt.setObject(5, u.getUserType());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	public boolean removeUser(User u) {
		getConnection();
        String query = "DELETE FROM users WHERE id=" + u.getId();
        boolean status = false;
        try {
            stmt = conn.createStatement();
            if (stmt.executeUpdate(query) != 0) {
                status = true;
            }

        } catch (SQLException e) {

            System.out.println("Target Has Eluded Capture");

        }
        return status;
    }
	
}
