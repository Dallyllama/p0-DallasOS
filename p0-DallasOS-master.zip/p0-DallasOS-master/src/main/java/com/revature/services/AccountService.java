package com.revature.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.revature.beans.Account;
import com.revature.beans.Account.AccountType;
import com.revature.beans.Transaction;
import com.revature.beans.User;
import com.revature.beans.Transaction.TransactionType;
import com.revature.dao.AccountDao;
import com.revature.exceptions.OverdraftException;
import com.revature.exceptions.UnauthorizedException;
import com.revature.utils.SessionCache;

/**
 * This class should contain the business logic for performing operations on Accounts
 */
public class AccountService {
	
	public AccountDao actDao;
	public static final double STARTING_BALANCE = 25d;
	
	public AccountService(AccountDao dao) {
		this.actDao = dao;
	}
	
	/**
	 * Withdraws funds from the specified account
	 * @throws OverdraftException if amount is greater than the account balance
	 * @throws UnsupportedOperationException if amount is negative
	 */
	public void withdraw(Account a, Double amount) {
		double newBalance = 0;
		newBalance = a.getBalance() - amount;
		if (newBalance < 0 || !a.isApproved()) {
			throw new OverdraftException();
		} else if(amount < 0) {
			throw new UnsupportedOperationException();
		} else {
			a.setBalance(newBalance);
			System.out.println("Withdrawal Was Successful");
//			List<Transaction> transList;
//			if (a.getTransactions() == null) {
//				transList = new ArrayList<>();
//			} else {
//				transList = a.getTransactions();
//			}
//			Transaction trans = new Transaction();
//			trans.setAmount(amount);
//			trans.setType(TransactionType.WITHDRAWAL);
//			transList.add(trans);
//			a.setTransactions(transList);
			actDao.updateAccount(a);
		}
	}
	
	/**
	 * Deposit funds to an account
	 * @throws UnsupportedOperationException if amount is negative
	 */
	public void deposit(Account a, Double amount) {
		if (amount < 0 || !a.isApproved()) {
			throw new UnsupportedOperationException();
		}
			double newBalance = a.getBalance() + amount;
		if (amount < 0 || !a.isApproved()) {
			throw new UnsupportedOperationException();
		} else {
			a.setBalance(newBalance);
			System.out.println("Your Funds Have Been Secured!");
//			List<Transaction> transList;
//			if (a.getTransactions() == null) {
//				transList = new ArrayList<>();
//			} else {
//				transList = a.getTransactions();
//			}
//			Transaction trans = new Transaction();
//			trans.setAmount(amount);
//			trans.setType(TransactionType.DEPOSIT);
//			transList.add(trans);
//			a.setTransactions(transList);
			actDao.updateAccount(a);
		}
	}
	
	/**
	 * Transfers funds between accounts
	 * @throws UnsupportedOperationException if amount is negative or 
	 * the transaction would result in a negative balance for either account
	 * or if either account is not approved
	 * @param fromAct the account to withdraw from
	 * @param toAct the account to deposit to
	 * @param amount the monetary value to transfer
	 */
	public void transfer(Account fromAct, Account toAct, double amount) {
		double newAmount = 0;
		double afterDeposit = 0;
		
		afterDeposit = fromAct.getBalance() - amount;
		newAmount = toAct.getBalance() + amount;
		
		try {
			fromAct.setBalance(afterDeposit);
			toAct.setBalance(newAmount);
			
			System.out.println("Wealth Successfully Transfered");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		actDao.updateAccount(fromAct);
		actDao.updateAccount(toAct);
	}
	
	/**
	 * Creates a new account for a given User
	 * @return the Account object that was created
	 */
	public Account createNewAccount(User u, boolean b) {
		int lgId = u.getId();
        Account acc = new Account();
        acc.setOwnerId(lgId);
        acc.setId(0);
        acc.setBalance(STARTING_BALANCE);
        acc.setApproved(false);
        if (b == false) {

            acc.setType(AccountType.SAVINGS);
        }
        else 
            acc.setType(AccountType.CHECKING);
        actDao.addAccount(acc);


        return acc;
    }
	
	public Account createNewAccount(User u, AccountType type) {
		Account a = new Account();
		List<Transaction> transactions = new ArrayList<>();
		a.setApproved(false);
		a.setBalance(STARTING_BALANCE);
		a.setOwnerId(u.getId());
		a.setType(type);
		actDao.addAccount(a);
		List<Account> accs;
		if (u.getAccounts() == null) {
			accs = new ArrayList<>();
		} else {
			accs = u.getAccounts();
		}
		accs = new ArrayList<>();
		accs.add(a);
		u.setAccounts(accs);
		return a;
	}
	
	/**
	 * Approve or reject an account.
	 * @param a
	 * @param approval
	 * @throws UnauthorizedException if logged in user is not an Employee
	 * @return true if account is approved, or false if unapproved
	 */
	public boolean approveOrRejectAccount(Account a, boolean approval) {
		Optional<User> u = SessionCache.getCurrentUser();
		if (u.isPresent()) {
			User user = u.get();
			if (user.getUserType() == User.UserType.EMPLOYEE) {
				a.setApproved(approval);
				actDao.updateAccount(a);
				return a.isApproved();
			} else {
				throw new UnauthorizedException();
			}
			
		}
		return false;
	}
}

