package com.revature.driver;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;

import com.revature.beans.User;
import com.revature.beans.Account.AccountType;
import com.revature.beans.User.UserType;
import com.revature.dao.AccountDaoDB;
import com.revature.dao.UserDao;
import com.revature.dao.UserDaoDB;
import com.revature.exceptions.InvalidCredentialsException;
import com.revature.exceptions.UsernameAlreadyExistsException;
import com.revature.utils.SessionCache;
import com.revature.beans.Account;
import com.revature.beans.Transaction;
import com.revature.services.*;

import java.sql.*;

/**
 * This is the entry point to the application
 */
public class BankApplicationDriver {

	// Set up Scanner
	private static Scanner input = new Scanner(System.in);
//	
//	//Call User Class
	private static User u = new User();

	public static Statement stmt;
	public static PreparedStatement pstmt;

	
	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		// Loading and registering the driver
		Class.forName("com.mysql.cj.jdbc.Driver");
		String dbUrl = "jdbc:mysql://localhost:3306/bankofaridholusers";
		String username = "root";
		String password = "root";

		// step 2: establish connection to the DB server
		Connection conn = DriverManager.getConnection(dbUrl, username, password);

		// step 3 = creating and running the queries
		UserDaoDB userDao = new UserDaoDB();
		Statement stmt = conn.createStatement();
		AccountDaoDB accountDao = new AccountDaoDB();
		AccountService accountService = new AccountService(accountDao);
		
		// User Choice
		int choice = 0;
		// Temp User Values
		int id = 0;
		String firstName = null;
		String lastName = null;
		String userName = null;
		String passWord = null;
		String userType = null;
		User newUser = null;
		Boolean run = true;

		User currentUser = null;
		UserService userService = new UserService(userDao, accountDao);
		SessionCache.setCurrentUser(currentUser);
		
// Start of Project Scope
		while (run) {		
	//Start of Login Scope
		if (!SessionCache.getCurrentUser().isPresent()) {
				System.out.println("Welcome to the Bank of Aridhol");
				System.out.println("==========================");
				System.out.println("1)	Login as an Exisiting User");
				System.out.println("2)	Register For an Account");
				System.out.println("3)	Exit");
				System.out.println("==========================");
				System.out.print("Enter Choice: ");
				choice = input.nextInt();

				switch (choice) {

				case 1: // Login
					System.out.println("==========================");
					System.out.println("Please Enter Your Username: ");
					userName = input.next();
					System.out.println("Please Enter Your Password: ");
					passWord = input.next();

					try {
						userService.login(userName, passWord);
//						SessionCache.setCurrentUser(newUser);
					} catch (InvalidCredentialsException e) {
						// TODO Auto-generated catch block
						System.out.println("Invalid Login Credentials, Summoning Bael Fire");
						System.out.println("==========================");
					}

					break;

				case 2: // Register
					System.out.println("Enter First Name: ");
					firstName = input.next();
					System.out.println("Enter Last Name: ");
					lastName = input.next();
					System.out.println("Enter Username: ");
					userName = input.next();
					System.out.println("Enter Password: ");
					passWord = input.next();

					// System.out.println("Enter User Type: ");
					try {
						newUser = new User(firstName, lastName, userName, passWord, UserType.CUSTOMER);
						newUser.setId(0);
						userService.register(newUser);
						
					} catch (UsernameAlreadyExistsException e) {
						// TODO Auto-generated catch block
						System.out.println("Imposter! Die Darkfriend!");
						System.out.println("==========================");
					}
					break;

				case 3:
					System.out.println("Thank you for choosing the Bank of Aridhol, Dovienya Shak Ciyat Dale!!!");
					System.exit(0);
					run = false;
					break;

				default:
					System.out.println("Invalid entry");
					break;
				}
			
	//end of login scope
			}		

		else if (SessionCache.getCurrentUser().get().getUserType() == UserType.CUSTOMER) {
				System.out.println("Welcome to the Bank of Aridhol");
				System.out.println("===================================");
				System.out.println("1)	Display Wealth From All Vaults");
				System.out.println("2)	Deposit Into A Vault");
				System.out.println("3)	Withdraw Riches");
				System.out.println("4)	Bestow Wealth");
				System.out.println("5)	Apply For A New Vault");
				System.out.println("6)	Logout");
				System.out.println("===================================");
				System.out.print("Enter Choice: ");

				// Get choice from user
				choice = input.nextInt();
				// Check choice value
				switch (choice) {

				case 1: // Display All Accounts
					List<Account> accountList = accountDao.getAccountsByUser(SessionCache.getCurrentUser().get());
					for (Account a: accountList) {
						System.out.println("===================================");
						System.out.println("Enter: " + a.getId() + " to peer into your " + a.getType() + " Vault");
						System.out.println("===================================");
					}
					try {
						System.out.println("Enter Choice:");
						int nextI = input.nextInt();
						System.out.println(nextI);
						Account d = accountDao.getAccount(nextI);
						System.out.println("===================================");
						System.out.println("Your Balance is $" + d.getBalance());
						System.out.println("===================================");
					} catch (Exception e) {
						// TODO Auto-generated catch block
						System.out.println("Your Coffers Are Empty!!!");
						System.out.println("===================================");
					}
					break;

				case 2: // Deposit
					List<Account> accList = accountDao.getAccountsByUser(SessionCache.getCurrentUser().get());
					for (Account a: accList) {
						System.out.println("===================================");
						System.out.println("Enter: " + a.getId() + " to Deposit Into Your " + a.getType() + " Vault");
					}
					try {
						Account act2 = new Account();
						double amt1 = 0;
						System.out.println("Enter Choice:");
						int nextIt = input.nextInt();
						System.out.println("===================================");
						System.out.println("How Much Would You Like to Deposit?");
						amt1 = input.nextDouble();
						
						
						
						act2 = accountDao.getAccount(nextIt);
						accountService.deposit(act2, amt1);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						System.out.println("===================================");
						System.out.println("What Are You Trying To Pull?");
						System.out.println("===================================");
					}
					

					break;

				case 3: // Withdraw
					List<Account> accountsList = accountDao.getAccountsByUser(SessionCache.getCurrentUser().get());
					for (Account a: accountsList) {
						System.out.println("===================================");
						System.out.println("Enter: " + a.getId() + " to Withdraw From Your " + a.getType() + " Vault");
					}
					try {
						Account a2 = new Account();
						double amt = 0;
						System.out.println("Enter Choice:");
						int nextI = input.nextInt();
						System.out.println("===================================");
						System.out.println("How Much Would You Like to Withdraw?");
						amt = input.nextDouble();
						
						
						
						a2 = accountDao.getAccount(nextI);
						accountService.withdraw(a2, amt);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						System.out.println("===================================");
						System.out.println("You Cannot Do That");
						System.out.println("===================================");
					}
					

					break;

				case 4: // Transfer
					Account toActId = new Account();
					int toId = 0;

					Account fromAcctId = new Account();
					int fromId = 0;

					double transAmt = 0;

					System.out.println("Which Vault Will You Be Withdrawing From?");
					fromId = input.nextInt();

					System.out.println("Where Should We Place These Funds?");
					toId = input.nextInt();

					System.out.println("Enter the Amount You Would Like to Transfer");
					transAmt = input.nextDouble();

					try {
						toActId = accountDao.getAccount(toId);
						fromAcctId = accountDao.getAccount(fromId);

						accountService.transfer(fromAcctId, toActId, transAmt);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						System.out.println("We Are Unable to Carry Out Your Request");
					}
					
					break;
					
				case 5: // Apply for new account
					System.out.println("==========================================");
					System.out.println("What Type of Vault Are You Interested In?");
					System.out.println("1)	Checking");
					System.out.println("2)	Savings");
					System.out.println("==========================================");
					System.out.print("Enter Choice: ");
					int register;
					register = input.nextInt();
					
					switch (register) {
						case 1:
							boolean typea = true;
							Optional <User> u = SessionCache.getCurrentUser();
							User got = u.get();
							accountService.createNewAccount(got, typea);
									                    									
							break;
							
						case 2:
							boolean typeb = false;
							Optional <User> blu = SessionCache.getCurrentUser();
							User gotgot = blu.get();
							accountService.createNewAccount(gotgot, typeb);
							
							break;
						}
					
					break;

				case 6: // Logout
					System.out.println("Thank you for choosing the Bank of Aridhol, Dovienya Shak Ciyat Dale!!!");
					SessionCache.setCurrentUser(null);
					break;

				default:
					System.out.println("Invalid entry");
					break;

				}}
		//End of Customer Menu Scope
				
			else if (SessionCache.getCurrentUser().get().getUserType() == UserType.EMPLOYEE) {
		//Start of Employee menu
				while (choice <= 5) {
		
					// display menu
					System.out.println("Welcome to the Bank of Aridhol");
					System.out.println("==========================");
					System.out.println("1)	Display All Users");
					System.out.println("2)	Add a New User");
					System.out.println("3)	Update an Existing User");
					System.out.println("4)	Delete a User");
					System.out.println("5)	Exit");
					System.out.println("==========================");
					System.out.print("Enter Choice: ");
		
					// Get choice from user
					choice = input.nextInt();
					// Check choice value
					switch (choice) {
		
					case 1: // Display all users
						System.out.println("Lets see who stores their riches with the Bank of Aridhol!");
						System.out.println("Under the Light: ");
						System.out.println(userDao.getAllUsers());
						
						break;
		
					case 2: // Create a new user
						System.out.println("Enter First Name: ");
						firstName = input.next();
						System.out.println("Enter Last Name: ");
						lastName = input.next();
						System.out.println("Enter Username: ");
						userName = input.next();
						System.out.println("Enter Password: ");
						passWord = input.next();
						
						newUser = new User(firstName, lastName, userName, passWord, UserType.CUSTOMER);
						newUser.setId(0);
						userDao.addUser(newUser);
						break;
		
					case 3: // Update an existing user
						System.out.println("Please enter the ID of the user you would like to edit: ");
						id = input.nextInt();
		
						System.out.println("Enter First Name: ");
						firstName = input.next();
						System.out.println("Enter Last Name: ");
						lastName = input.next();
						System.out.println("Enter Username: ");
						userName = input.next();
						System.out.println("Enter Password: ");
						passWord = input.next();
						// System.out.println("Enter User Type: ");
						newUser = new User(firstName, lastName, userName, passWord, UserType.CUSTOMER);
						newUser.setId(0);
						userDao.addUser(newUser);
						break;
		
					case 4: // Delete a user account
						System.out.println("Please enter the ID of the user you would like dealt with");
						id = input.nextInt();
						
						try {
							User u = new User();
							u.setId(id);
							userDao.removeUser(u);
						} catch (Exception e) {
							System.out.println("Target Has Eluded Capture");
						}
						System.out.println("Target Has Been Eliminated");
						break;
		
					case 5:
						System.out.println("Thank you for choosing the Bank of Aridhol, Dovienya Shak Ciyat Dale!!!");
						
						SessionCache.setCurrentUser(null);
						
						break;
		
					default:
						System.out.println("Invalid entry");
						break;
							}
					} 
			//End of Employee Menu					
					}
				}
		input.close();
			}
			
//End of Program Scope
		}

		//System.out.println(!SessionCache.getCurrentUser().isPresent());